#!/usr/bin/python
import tkinter as tk
from tkinter import simpledialog, messagebox
import Rendering._3DList as l
import Rendering.renderingEngine as r
import pygame
from pygame.locals import *
import math
import os
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath)
os.chdir(dname)

root = tk.Tk()
root.withdraw()

icon = pygame.image.load('logo.png')
pygame.display.set_icon(icon)

def img(path):
    return pygame.image.load("menu/"+path+".png").convert()


def xpos(width,x):
    return x + width/2


def ypos(height,y):
    return -y - height/2


def ask(title, question):
    return simpledialog.askstring(title,question,parent=root)


def main_menu(width, height):
    screen = pygame.display.set_mode((width, height))
    screen.fill((255, 255, 255))
    pygame.display.set_icon(icon)
    ititle = img("name")
    ititle = pygame.transform.scale(ititle, (round(width/4),round((width/4)*(26/85))))
    iplay = img("play")
    iplay = pygame.transform.scale(iplay, (round(width/5),round((width/5)*(65/204))))
    ioptions = img("options")
    ioptions = pygame.transform.scale(ioptions, (round(width / 5), round((width / 5) * (65 / 204))))
    iquit = img("quit")
    iquit = pygame.transform.scale(iquit, (round(width / 5), round((width / 5) * (65 / 204))))
    icredits = img("credits")
    icredits = pygame.transform.scale(icredits, (round(width / 5), round((width / 5) * (65 / 204))))
    ihelp = img("help")
    ihelp = pygame.transform.scale(ihelp, (round(width / 5), round((width / 5) * (65 / 204))))
    screen.blit(ititle,(3*width/8,height/100))
    screen.blit(iplay, (width/2-width/10,height*6/30))
    screen.blit(ioptions, (width / 2 - width / 10, height * 11 / 30))
    screen.blit(iquit, (width / 2 - width / 10, height * 16 / 30))
    pygame.display.flip()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                loc = pygame.mouse.get_pos()
                if iplay.get_rect().collidepoint(loc[0]-width/2+width/10,loc[1]-height*6/30):
                    return "pick-world"
                if ioptions.get_rect().collidepoint(loc[0]-width/2+width/10,loc[1]-height*11/30):
                    return "options"
                if iquit.get_rect().collidepoint(loc[0]-width/2+width/10,loc[1]-height*16/30):
                    return "quit"

def pick_world_menu(width, height):
    screen = pygame.display.set_mode((width, height))
    screen.fill((230, 230, 230))
    inew = img("newworld")
    inew = pygame.transform.scale(inew, (round(width / 5), round((width / 5) * (65 / 204))))
    iopen = img("openworld")
    iopen = pygame.transform.scale(iopen, (round(width / 5), round((width / 5) * (65 / 204))))
    iback = img("back")
    iback = pygame.transform.scale(iback, (round(width / 5), round((width / 5) * (65 / 204))))
    screen.blit(inew, (width - height / 25 - width / 5, height / 25))
    screen.blit(iopen,(height/25,height/25))
    screen.blit(iback,(width-height/25-width/5,height-height/25-(width / 5) * (65 / 204)))
    pygame.display.flip()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                loc = pygame.mouse.get_pos()
                if iopen.get_rect().collidepoint(loc[0]-height/25,loc[1]-height/25):
                    return "openworld"
                if inew.get_rect().collidepoint(loc[0]-width + height / 25 + width / 5,loc[1]-height / 25):
                    return "newworld"
                if iback.get_rect().collidepoint(loc[0]-width+height/25+width/5,loc[1]-height+height/25+(width / 5) * (65 / 204)):
                    return "main"

def instructions(width,height):
    pass


def main(width,height):
    running = True
    menu = "main"
    while running:
        if menu == "main":
            menu = main_menu(width,height)
            continue
        elif menu == "pick-world":
            menu = pick_world_menu(width,height)
            continue
        elif menu == None or menu == "quit":
            running = False
            continue
        elif menu == "newworld":
            try:
                name = ask("World Name", "What should be the name of the world?") + ".pcw"
            except TypeError:
                menu = "pick-world"
                continue
            settings = open("settings/numerical_settings.pcs").read().split('\n')
            settings = [a.split(":") for a in settings]
            for x in settings:
                if len(x) != 2:
                    settings.pop(settings.index(x))
            settings = dict(settings)
            for iter in settings:
                settings[iter] = int(settings[iter])
            world = l._3DList(settings["xworldsize"],settings["yworldsize"],settings["zworldsize"])
            world.hand = [(0, 1, 0),(1, 0, 0),(1, 0, 1),(0, 0, 1),(1, 1, 0),(0, 1, 1)]
            menu = r.main(world,round(settings["xworldsize"]/2)+.5,math.floor(settings["yworldsize"]/2)+.5,round(settings["zworldsize"]/2)+.5,width,height,settings["speed"])
            continue
        elif menu == "openworld":
            try:
                settings = open("settings/numerical_settings.pcs").read().split('\n')
                settings = [a.split(":") for a in settings]
                for x in settings:
                    if len(x) != 2:
                        settings.pop(settings.index(x))
                settings = dict(settings)
                for iter in settings:
                    settings[iter] = int(settings[iter])
                try:
                    name = ask("World Name", "What is the name of the world?") + ".pcw"
                except TypeError:
                    menu = "pick-world"
                    continue
                thing = open("saves/"+name).read().split("\n")[0].split(" ")
                thing = [float(x) for x in thing]
                thing2 = open("saves/" + name).read().split("\n")[1].split(" ")
                thing2 = [float(x) for x in thing2]
                thing2 = [thing2[x[0] * 3:x[0] * 3 + 3] for x in enumerate(thing2[::3])]
                dims = l.get_file_dimensions(name)
                world = l._3DList(dims[0],dims[1],dims[2])
                world.load(name, lists=True)
                world.hand = thing2
                menu = r.main(world,thing[0],thing[1],thing[2],width,height,settings["speed"])
                continue
            except FileNotFoundError:
                messagebox.showerror("World not Found", "There is no world with that name", parent=root)
                continue
        elif menu[0] == "saveandquit":
            world.save(name, menu[1], menu[2], menu[3], world.hand)
            pygame.mouse.set_visible(True)
            pygame.quit()
            menu = "main"
            continue
        elif menu == "options":
            os.system("gnome-text-editor ./settings/numerical_settings.pcs")
            menu = "main"
            #messagebox.showinfo("How to change settings", "To change the settings, go to the settings folder and open the file there and modify whichever settings you like")
        else:
            menu = main_menu(width,height)
            continue

pygame.init()
pygame.display.set_caption('PyCraft')
width, height = 1220, 650
screen = pygame.display.set_mode((width,height))
screen.fill((255,255,255))
main(width,height)
pygame.quit()
