import _3DList as l
import renderingEngine as r
block = [
    [0,1,0],
    [1,0,0],
    [1,0,1],
    [0,0,1],
    [1,1,0],
    [0,1,1]
]
dims = l.get_file_dimensions("testworld.pcw")
ls = l._3DList(dims[0],dims[1],dims[2])
ls.load("testworld.pcw",lists=True)

r.main(ls, 25, 25.5, 25, 1220, 650, (50, 50, 50),7)
