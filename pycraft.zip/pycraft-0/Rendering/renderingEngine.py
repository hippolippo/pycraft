import pygame
import time
from tkinter import *
from tkinter.colorchooser import askcolor
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
from math import sin, cos, floor, ceil, atan, radians, degrees, cos


def deg(num):
    return degrees(num)


def r(num):
    return radians(num)


def get_looking_at(xrot, yrot, xpos, ypos, zpos, blocks, reach):
    '''print(xpos,ypos,zpos)
    print(xrot,yrot)
    xrot, yrot = math.radians(xrot), math.radians(yrot)
    ##OLD CODE
    xlook = math.cos(xrot) * math.cos(yrot)
    ylook = (1-math.cos(yrot))**0.5
    zlook = math.cos(yrot) * math.sin(xrot)
    print(xlook,ylook,zlook)
    #Begin Trace
    #Trace X (east/west)
    xIntercepts = list()
    for x in range(reach):
        xl = x + round(xpos) + .5
        if xrot < 0 or xrot > math.pi:
            xl = -lx
            x = -x
        y = (x*ylook)/xlook + ypos
        z = (x*zlook)/xlook + zpos
        xIntercepts.append((xl,y,z))
    #Trace Y (top/bottom)
    yIntercepts = list()
    for y in range(reach):
        y = ypos + y
        y = math.ceil(y)
        if yrot < 0 or yrot > math.pi:
            y = -y
            
        x = (y*xlook)/ylook
        z = (y*zlook)/xlook
        yIntercepts.append((x,y,z))
    #Trace Z (north/south)
    zIntercepts = list()
    for z in range(reach):
        z = z + zpos
        z = round(z)
        z += .5
        if xrot < -math.pi/2 or xrot > math.pi/2:
            z = -z
        x = (z*xlook)/zlook
        y = (z*ylook)/zlook
        zIntercepts.append((x,y,z))
    if xrot > 0 and xrot < math.pi:
        xface = "West"
    else:
        xface = "East"
    if xrot > -math.pi/2 and xrot < math.pi/2:
        zface = "South"
    else:
        zface = "North"
    if yrot > 0 and yrot < math.pi:
        yface = "Top"
    else:
        yface = "Bottom"
    blocksDistance = dict()
    for i in xIntercepts:
        blocksDistance[sum(i)]=(i[0],i[1],i[2],xface)
    for i in yIntercepts:
        blocksDistance[sum(i)]=(i[0],i[1],i[2],yface)
    for i in zIntercepts:
        blocksDistance[sum(i)]=(i[0],i[1],i[2],zface)
    lookingAt = [(x,)+blocksDistance[x] for x in blocksDistance]
    ##END OLD CODE
    xform = sin(xrot)*cos(yrot)+xpos
    yform = sin(yrot)+ypos
    zform = -(cos(xrot)*cos(yrot))+zpos
    xforward = xform-xpos >= 0
    yforward = yform-ypos >= 0
    zforward = zform-zpos >= 0
    if xforward:
        xset = [floor(x+xpos+.5)+.5 for x in range(reach)]
    else:
        xset = [floor((-x)+xpos+.5)-.5 for x in range(reach)]
    if yforward:
        yset = [ceil(y+ypos) for y in range(reach)]
    else:
        yset = [floor((-y)+ypos) for y in range(reach)]
    if zforward:
        zset = [floor(z+zpos+.5)+.5 for z in range(reach)]
    else:
        zset = [floor((-x)+xpos+.5)-.5 for x in range(reach)]
    xint = []
    yint = []
    zint = []
    for x in xset:
        y = ((yform-ypos)*x)/(xform-xpos)
        z = ((zform-zpos)*x)/(xform-xpos)
        xint.append((x, y+ypos, z+zpos))
    for y in yset:
        x = ((xform-xpos)*y)/(yform-ypos)
        z = ((zform-zpos)*y)/(yform-ypos)
        yint.append((x+xpos, y, z+zpos))
    for z in zset:
        x = ((xform-xpos)*z)/(zform-zpos)
        y = ((yform-ypos)*z)/(zform-zpos)
        zint.append((x+xpos,y+ypos,z))
    intercepts = dict()
    for pos in xint:
        intercepts[(pos[0]-xpos)**2+(pos[1]-ypos)**2+(pos[2]-zpos)**2] = (pos[0], pos[1], pos[2], "x")
    for pos in yint:
        intercepts[(pos[0]-xpos)**2+(pos[1]-ypos)**2+(pos[2]-zpos)**2] = (pos[0], pos[1], pos[2], "y")
    for pos in zint:
        intercepts[(pos[0]-xpos)**2+(pos[1]-ypos)**2+(pos[2]-zpos)**2] = (pos[0], pos[1], pos[2], "z")
    indices = [x for x in intercepts]
    indices.sort()
    for index in indices:
        connection = intercepts[index]
        print(connection)
        if xforward:
            x = floor(connection[0]+.5)
            xdir = "e"
        else:
            x = ceil(connection[0]-.5)
            xdir = "w"
        if yforward:
            y = floor(connection[1])
            ydir = "d"
        else:
            y = floor(connection[1])+1
            ydir = "u"
        if zforward:
            z = ceil(connection[2]-.5)
            zdir = "n"
        else:
            z = floor(connection[2]+.5)
            zdir = "s"
        print(x,y,z)
        try:
            if blocks.get_data(x, y, z) != None:
                if math.sqrt(index) <= reach:
                    if connection[3] == "x":
                        return x, y, z, xdir
                    if connection[3] == "y":
                        return x, y, z, ydir
                    if connection[3] == "z":
                        return x, y, z, zdir
                else:
                    return
            else:
                continue
        except IndexError:
            continue
    return
    '''
    rx = xpos % 1
    rz = zpos % 1
    ry = ypos % 1
    if rx == 0:
        rx += .0001
    if ry == 0:
        ry += .0001
    if rz == 0:
        rz += .0001
    br = deg(atan((1-rx)/(1-rz)))
    fr = deg(atan((1-rx)/rz))+90
    fl = deg(atan(rx/rz))-180
    bl = deg(-atan(rx/(1-rz)))
    br, fr, fl, bl = (br+180)%360-180, (fr+180)%360-180, (fl+180)%360-180, (bl+180)%360-180
    xrot, yrot = (xrot+180)%360-180, (yrot+180)%360-180
    if xrot >= bl and xrot < br:
        hdir = "n"
    if xrot >= br and xrot < fr:
        hdir = "e"
    if xrot >= fr or xrot < fl:
        hdir = "s"
    if xrot >= fl and xrot < bl:
        hdir = "w"
    if hdir == "n":
        u = atan(((1-ry)*cos(r(xrot)))/(1-rz))
        d = -atan((ry*cos(r(xrot)))/(1-rz))
    if hdir == "s":
        u = atan(((1-ry)*cos(r(180-xrot)))/rz)
        d = atan((ry*cos(r(180-xrot)))/rz)
    if hdir == "e":
        u = atan(((1 - ry) * cos(r(90 - xrot))) / rz)
        d = atan((ry * cos(r(90 - xrot))) / rz)
    if hdir == "w":
        u = atan(((1 - ry) * cos(r(90 + xrot))) / rz)
        d = atan((ry * cos(r(90 + xrot))) / rz)
    u, d = (u+180)%360-180, (d+180)%360+180
    x, y, z = round(xpos), floor(ypos), round(zpos)
    if r(yrot) >= u:
        y += 1
    elif r(yrot) <= d:
        y -= 1
    elif hdir == "n":
        z += 1
    elif hdir == "s":
        z -= 1
    elif hdir == "e":
        x += 1
    elif hdir == "w":
        x -= 1
    return x, y, z


def render_area(x, y, z, area):
    for block in area.iterate():
        cube(block[0][0] - x, block[0][1] - y, block[0][2] - z, block[1])


def place(x, y, z, blocks, hand):
    try:
        current = blocks.get_data(x, y, z)
        if current == None:
            blocks.set_data(x, y, z, hand)
            return
        else:
            return
    except IndexError:
        return


def destroy(x, y, z, blocks):
    try:
        blocks.set_data(x, y, z, None)
        return
    except IndexError:
        return


def cube(x, y, z, color):
    glBegin(GL_QUADS)
    glColor3f(color[0][0], color[0][1], color[0][2])  # N
    glVertex3f(x + .5, y + 1, z + .5)
    glVertex3f(x - .5, y + 1, z + .5)
    glVertex3f(x - .5, y, z + .5)
    glVertex3f(x + .5, y, z + .5)
    glColor3f(color[1][0], color[1][1], color[1][2])  # S
    glVertex3f(x - .5, y + 1, z - .5)
    glVertex3f(x + .5, y + 1, z - .5)
    glVertex3f(x + .5, y, z - .5)
    glVertex3f(x - .5, y, z - .5)
    glColor3f(color[2][0], color[2][1], color[2][2])  # W
    glVertex3f(x + .5, y + 1, z - .5)
    glVertex3f(x + .5, y + 1, z + .5)
    glVertex3f(x + .5, y, z + .5)
    glVertex3f(x + .5, y, z - .5)
    glColor3f(color[3][0], color[3][1], color[3][2])  # E
    glVertex3f(x - .5, y + 1, z + .5)
    glVertex3f(x - .5, y + 1, z - .5)
    glVertex3f(x - .5, y, z - .5)
    glVertex3f(x - .5, y, z + .5)
    glColor3f(color[4][0], color[4][1], color[4][2])  # U
    glVertex3f(x + .5, y + 1, z - .5)
    glVertex3f(x - .5, y + 1, z - .5)
    glVertex3f(x - .5, y + 1, z + .5)
    glVertex3f(x + .5, y + 1, z + .5)
    glColor3f(color[5][0], color[5][1], color[5][2])  # D
    glVertex3f(x + .5, y, z - .5)
    glVertex3f(x + .5, y, z + .5)
    glVertex3f(x - .5, y, z + .5)
    glVertex3f(x - .5, y, z - .5)
    glEnd()


def crosshair(x, y, w):
    glColor3f(.8, .8, .8)
    glBegin(GL_LINES)
    glVertex2f(x-w, y)
    glVertex2f(x+w, y)
    glVertex2f(x, y-w)
    glVertex2f(x, y+w)
    glEnd()


def compass(radius, margin, xrot,height):
    glColor3f(0,0,0)
    glBegin(GL_LINES)
    cosine = radius * cos(0 * 2 * math.pi / 32) + margin
    sine = radius * sin(0 * 2 * math.pi / 32) + margin
    glVertex2f(cosine, height-sine)
    for i in range(33):
        cosine = radius * cos(i*2*math.pi/32) + margin
        sine = radius * sin(i*2*math.pi/32) + margin
        glVertex2f(cosine,height-sine)
        glVertex2f(cosine, height-sine)
    glVertex2f(cosine,height-sine)
    glColor3f(1,0,0)
    glVertex2f(margin, height - margin)
    glVertex2f(margin+sin(r(xrot))*radius*.9,height-margin+cos(r(xrot))*radius*.9)
    glEnd()

running = None


def to_hex(rgb):
    chars = "0123456789ABCDEF"
    output = "#"
    for x in rgb:
        x *= 255
        x = round(x)
        if x > 255:
            x = 255
        elif x < 0:
            x = 0
        d1 = floor(x / 16)
        d2 = round(x % 16)
        output += chars[d1]
        output += chars[d2]
    return output


def rgb(hx):
    chars = "0123456789ABCDEF"
    group1 = hx[1:3]
    group2 = hx[3:5]
    group3 = hx[5:]
    r = (chars.index(group1[0])*16+chars.index(group1[1]))/255
    g = (chars.index(group2[0])*16+chars.index(group2[1]))/255
    b = (chars.index(group3[0])*16+chars.index(group3[1]))/255
    return r, g, b

def get_color(color):
    color = askcolor(color)
    if color == (None,None):
        return
    else:
        return tuple([x/255 for x in color[0]])

'''
def auto_block(color):
    section = 1/7
    order = (5,3,1,0,2,4)
    hand = [(),(),(),(),(),()]
    if color[0] == color[1] and color[0] == color[2]:
        location = ceil(color[0]/section)
        spot = 0
        for x in range(1,8):
            if x == location:
                continue
            change = (x - location)*4/255
            hand[spot] = (color[0]+change,color[0]+change,color[0]+change)
            spot += 1
        return hand
    elif color[0] == color[1] or color[0] == color[2] or color[1] == color[2]:
        '''


global value
def pick_color(hand):
    global value
    running = True
    newhand = list(hand)
    value = hand
    colorWindow = Tk()
    colorWindow.title("Block Selection")
    canvas = Canvas(colorWindow, width=1050, height=300)
    canvas.grid(row=1,column=1,columnspan=2)
    def gethand():
        global value
        running = False
        colorWindow.destroy()
        value = newhand
    done = Button(colorWindow,text="Done",command = gethand)
    done.grid(row=2,column=1)

    def oldhand():
        running = False
        colorWindow.destroy()
    cancel = Button(colorWindow,text="Cancel",command = oldhand)
    cancel.grid(row=2,column=2)

    canvas.create_text(150, 100, text="N")
    canvas.create_text(300, 100, text="S")
    canvas.create_text(450, 100, text="W")
    canvas.create_text(600, 100, text="E")
    canvas.create_text(750, 100, text="U")
    canvas.create_text(900, 100, text="D")

    rectSize = 35
    n = canvas.create_rectangle(150 - rectSize, 200 - rectSize, 150 + rectSize, 200 + rectSize, fill=to_hex(newhand[0]))
    s = canvas.create_rectangle(300 - rectSize, 200 - rectSize, 300 + rectSize, 200 + rectSize, fill=to_hex(newhand[1]))
    w = canvas.create_rectangle(450 - rectSize, 200 - rectSize, 450 + rectSize, 200 + rectSize, fill=to_hex(newhand[2]))
    e = canvas.create_rectangle(600 - rectSize, 200 - rectSize, 600 + rectSize, 200 + rectSize, fill=to_hex(newhand[3]))
    u = canvas.create_rectangle(750 - rectSize, 200 - rectSize, 750 + rectSize, 200 + rectSize, fill=to_hex(newhand[4]))
    d = canvas.create_rectangle(900 - rectSize, 200 - rectSize, 900 + rectSize, 200 + rectSize, fill=to_hex(newhand[5]))

    def north(event):
        new_color = get_color(to_hex(newhand[0]))
        if new_color == None:
            return
        canvas.itemconfigure(n, fill=to_hex(new_color))
        newhand[0] = new_color
    def south(event):
        new_color = get_color(to_hex(newhand[1]))
        if new_color == None:
            return
        canvas.itemconfigure(s, fill=to_hex(new_color))
        newhand[1] = new_color
    def west(event):
        new_color = get_color(to_hex(newhand[2]))
        if new_color == None:
            return
        canvas.itemconfigure(w, fill=to_hex(new_color))
        newhand[2] = new_color
    def east(event):
        new_color = get_color(to_hex(newhand[3]))
        if new_color == None:
            return
        canvas.itemconfigure(e, fill=to_hex(new_color))
        newhand[3] = new_color
    def up(event):
        new_color = get_color(to_hex(newhand[4]))
        if new_color == None:
            return
        canvas.itemconfigure(u, fill=to_hex(new_color))
        newhand[4] = new_color
    def down(event):
        new_color = get_color(to_hex(newhand[5]))
        if new_color == None:
            return
        canvas.itemconfigure(d, fill=to_hex(new_color))
        newhand[5] = new_color

    canvas.tag_bind(n, '<ButtonPress-1>', north)
    canvas.tag_bind(s, '<ButtonPress-1>', south)
    canvas.tag_bind(w, '<ButtonPress-1>', west)
    canvas.tag_bind(e, '<ButtonPress-1>', east)
    canvas.tag_bind(u, '<ButtonPress-1>', up)
    canvas.tag_bind(d, '<ButtonPress-1>', down)

    while running:
        try:
            colorWindow.update()
        except:
            break
    return value


def main(world,x,y,z,width,height,speed):
    rightClicked = False
    leftClicked = False
    middleClicked = False
    currentColor = (186, 243, 255)
    xrot = 0
    yrot = 0
    screen = pygame.display.set_mode((width,height), DOUBLEBUF | OPENGL)
    glClearColor(0.0, 0.0, 0.0, 0.0)
    glClearDepth(1.0)
    glDepthMask(GL_TRUE)
    glDepthFunc(GL_LESS)
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_CULL_FACE)
    glCullFace(GL_BACK)
    glFrontFace(GL_CCW)
    glShadeModel(GL_SMOOTH)
    glDepthRange(0.0, 1.0)

    glMatrixMode(GL_PROJECTION)
    gluPerspective(45, (width/height), 0.1, 100.0)
    glMatrixMode(GL_MODELVIEW)
    glPushMatrix()

    pygame.mouse.set_visible(False)
    facing = [0, 0, False]
    pressedKeys = {119:False,97:False,115:False,100:False,32:False,304:False,108:False,101:False}
    endTime = time.time()
    while True:
        startTime = time.time()
        newMousePos = pygame.mouse.get_pos()
        change = [newMousePos[0]-(width/2), newMousePos[1]-(height/2)]
        pygame.mouse.set_pos([width / 2, height / 2])
        modelview = glGetFloatv(GL_MODELVIEW_MATRIX)
        glLoadIdentity()
        yrot -= change[1]*0.1
        if yrot > 90:
            yrot += change[1]*.1
            change[1] = 0
        if yrot < -90:
            yrot += change[1]*.1
            change[1] = 0
        glRotate(change[1]*0.1, 1, 0, 0)
        glMultMatrixf(modelview)
        xrot += change[0]*0.1
        xrot = (xrot+180)%360-180
        glRotate(change[0]*0.1, 0, 1, 0)
        glClearDepth(1.0)
        glClearColor(.5, 1, 1, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        for t in world.fullSlots:
            cube(t[0]-x,t[1]-y,t[2]-z,world.get_data(t[0],t[1],t[2]))

        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0.0, width, 0.0, height, -1.0, 1.0)
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        glDisable(GL_DEPTH_TEST)
        glLineWidth(3)
        crosshair(width/2, height/2, 20)
        compass(25,35,xrot, height)
        glEnable(GL_DEPTH_TEST)
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)
        glPopMatrix()
        glCullFace(GL_BACK)
        pygame.display.flip()
        time.sleep(.01)
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    return "saveandquit", x, y, z
                else:
                    pressedKeys[event.key] = True

            if event.type == pygame.KEYUP:
                pressedKeys[event.key] = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and not leftClicked:
                    leftClicked = True
                    looking = get_looking_at(xrot, yrot, x, y, z, world, 10)
                    destroy(looking[0], looking[1], looking[2], world)
                if event.button == 2 and not middleClicked:
                    middleClicked = True
                    looking = get_looking_at(xrot, yrot, x, y, z, world, 10)
                    if world.get_data(looking[0], looking[1], looking[2]) != None:
                        world.hand = world.get_data(looking[0], looking[1], looking[2])
                if event.button == 3 and not rightClicked:
                    rightClicked = True
                    looking = get_looking_at(xrot, yrot, x, y, z, world, 10)
                    place(looking[0], looking[1], looking[2], world, [x for x in world.hand])
            if event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    leftClicked = False
                if event.button == 2:
                    middleClicked = False
                if event.button == 3:
                    rightClicked = False
        endTime = time.time()
        elapsedTime = endTime-startTime
        step = speed*elapsedTime
        xmotion = math.sin(math.radians(xrot)) * step
        zmotion = math.cos(math.radians(xrot)) * step
        if pressedKeys[K_w]:
            x += xmotion
            z -= zmotion
        if pressedKeys[K_s]:
            x -= xmotion
            z += zmotion
        if pressedKeys[K_a]:
            xmotion = math.sin(math.radians(-90+xrot)) * step
            zmotion = math.cos(math.radians(-90+xrot)) * step
            x += xmotion
            z -= zmotion
        if pressedKeys[K_d]:
            xmotion = math.sin(math.radians(xrot+90)) * step
            zmotion = math.cos(math.radians(xrot+90)) * step
            x += xmotion
            z -= zmotion
        if pressedKeys[K_SPACE]:
            y += step
        if pressedKeys[K_LSHIFT]:
            y -= step
        if pressedKeys[K_e]:
            pygame.mouse.set_visible(True)
            world.hand = pick_color(world.hand)
            pygame.mouse.set_visible(False)
